package co.edu.unbosque.primerspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
